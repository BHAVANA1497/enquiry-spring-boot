package com.hrs.enquiry.rest.controller;

import com.hrs.enquiry.model.GuestDetails;
import com.hrs.enquiry.rest.exception.EnquiryException;
import com.hrs.enquiry.rest.json.*;
import com.hrs.enquiry.rest.mapper.JsonDomainMapper;
import com.hrs.enquiry.service.EnquiryService;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.util.List;

@RestController
@Slf4j
public class EnquiryController {

    private final EnquiryService enquiryService;

    @Autowired
    public EnquiryController(EnquiryService enquiryService) {this.enquiryService = enquiryService;}

    @PostMapping(value = "/add/guest")
    @ApiOperation(value = "Insert New Guest", httpMethod = "POST", consumes = "application/json")
    public RestResponse<GuestResponse> addNewGuest(@RequestBody GuestRequest request) {
        log.info("GuestResponse {}", request);
        GuestDetails guestDetails;
        RestResponse<GuestResponse> restResponse = new RestResponse<>();
        try{
            guestDetails = enquiryService.insert(JsonDomainMapper.jsonToDomain(request));

        }

        catch (Exception e){
            log.error(e.getMessage());
            restResponse.setStatus(Status.ERROR);
            restResponse.setMessage(e.getMessage());
            return restResponse;
        }
        restResponse.setData(JsonDomainMapper.domainToJson(guestDetails));
        return restResponse;

    }

    @GetMapping(path = "/guestDetails/checkedIn")
    @ApiOperation(value = "Get all Guest details checked In", httpMethod = "GET", consumes = "application/json")
    public RestResponse<List<GuestResponse>> findAll() {

        log.info("Get all ROEs");
        RestResponse<List<GuestResponse>> response = new RestResponse<>();
        List<GuestDetails> guestList = enquiryService.findAll();
        response.setData(JsonDomainMapper.domainToJson4List(guestList));
        return response;
    }

    @PutMapping(path = "/updatedetails/{roomNo}")
    @ApiOperation(value = "Update Guest Record with parcel details", httpMethod = "PUT", consumes = "application/json" )
    public RestResponse<GuestResponse> update(@NotBlank @PathVariable String roomNo, @Valid @RequestBody List<ParcelDetails> parcelreq){

    RestResponse<GuestResponse> response = new RestResponse<>();
    GuestDetails details;
    try{
        details = enquiryService.update(parcelreq, roomNo);

    }
    catch(EnquiryException e){
        log.error(e.getMessage());
        response.setStatus(Status.ERROR);
        response.setMessage(e.getMessage());
        return response;
    }
    GuestResponse guestResponse = JsonDomainMapper.domainToJson(details);
    response.setData(guestResponse);
    return response;
}
    @PutMapping(path = "/checkout/{roomNo}")
    @ApiOperation(value = "Update guest while checkout", httpMethod = "PUT", consumes = "application/json")
    public RestResponse<GuestResponse> updateWhilecheckOut(@NotBlank @PathVariable String roomNo){

        RestResponse<GuestResponse> restResponse = new RestResponse<>();
        GuestDetails details;
        try{
            details = enquiryService.updateWhileCheckOut(roomNo);
        }catch(EnquiryException e){
            log.error(e.getMessage());
            restResponse.setStatus(Status.ERROR);
            restResponse.setMessage(e.getMessage());
            return restResponse;
        }
        GuestResponse guestResponse = JsonDomainMapper.domainToJson(details);
        restResponse.setData(guestResponse);
        return restResponse;
    }


}
