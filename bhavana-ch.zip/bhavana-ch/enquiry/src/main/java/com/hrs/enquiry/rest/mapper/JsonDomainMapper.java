package com.hrs.enquiry.rest.mapper;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hrs.enquiry.model.GuestDetails;
import com.hrs.enquiry.rest.json.GuestRequest;
import com.hrs.enquiry.rest.json.GuestResponse;
import com.hrs.enquiry.rest.json.ParcelDetails;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public class JsonDomainMapper {

    private JsonDomainMapper() {}

    public static GuestDetails jsonToDomain(GuestRequest guestRequest) {
        String parcelDetailsJson = null;
        try {
            ObjectMapper mapper = new ObjectMapper();
            parcelDetailsJson = mapper.writeValueAsString(guestRequest.getParcelDetailsJson());
            log.info("parcel Details json: {}", parcelDetailsJson);
        } catch (Exception e) {
            log.info("unhandled excep {}", e.getCause());
            //TODO: handle exception
        }
        if (guestRequest == null)
            return null;

        GuestDetails guestDetails = GuestDetails.builder()
                .status(guestRequest.getGuestName())
                .guestName(guestRequest.getGuestName())
                .roomNo(guestRequest.getRoomNo())
                .parcelDetailsJson(parcelDetailsJson)
                .typeOfRoom(guestRequest.getTypeOfRoom())
                .noOfGuests(guestRequest.getNoOfGuests()).build();

        return guestDetails;
    }

    public static GuestResponse domainToJson(GuestDetails guestDetails){
        if(guestDetails == null)
            return null;

        ObjectMapper mapper = new ObjectMapper();
        List<ParcelDetails> parcelDetailsJson = null;

        try {
            parcelDetailsJson = (guestDetails.getParcelDetailsJson() != null ? mapper.readValue(guestDetails.getParcelDetailsJson(), new TypeReference<List<ParcelDetails>>() {
            }) : null);
        } catch (IOException e) {
            log.info("Exception {}", e.getMessage());

        }
        return GuestResponse.builder()
                .guestId(guestDetails.getGuestId())
                .roomNo(guestDetails.getRoomNo())
                .guestName(guestDetails.getGuestName())
                .noOfGuests(guestDetails.getNoOfGuests())
                .status(guestDetails.getStatus())
                .checkInTime(guestDetails.getCheckInTime()!= null ? guestDetails.getCheckInTime().toString() : null )
                .parcelDetailsJson(parcelDetailsJson)
                .typeOfRoom(guestDetails.getTypeOfRoom())
                .checkOutTime(guestDetails.getCheckOutTime()!= null ? guestDetails.getCheckOutTime().toString() : null)
                .build();
    }
    public static List<GuestResponse> domainToJson4List(List<GuestDetails> roeList){
        return roeList.stream().map(JsonDomainMapper::domainToJson).collect(Collectors.toList());
    }


}
