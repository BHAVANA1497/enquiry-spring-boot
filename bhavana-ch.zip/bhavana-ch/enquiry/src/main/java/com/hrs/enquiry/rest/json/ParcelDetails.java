package com.hrs.enquiry.rest.json;


import lombok.*;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class ParcelDetails {

    private int parcelId;

    private String additionalInfo;
}
