package com.hrs.enquiry.rest.json;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class GuestResponse {

    @ApiModelProperty(value = "Primary Key for this record", required = true, example = "1")
    @NotNull
    private long guestId;

    @ApiModelProperty(value = "Status of the Guest: CHECKED_IN, CHECKED_OUT", required = true, example = "CHECKED_IN")
    @NotNull
    private String status;

    @ApiModelProperty(value = "Room Number", required = true, example = "102")
    @NotNull
    @NotBlank
    private String roomNo;

    @ApiModelProperty(value = "Guest Name", required = true, example = "Alex")
    private String guestName;

    @ApiModelProperty(value = "Number Of Guests", required = true, example = "3")
    private int noOfGuests;

    @ApiModelProperty(value = "Type Of Room", required = true, example = "Deluxe")
    private String typeOfRoom;

    @ApiModelProperty(value = "Check In Time", required = true, example = "2021-02-08T23:00:00")
    private String checkInTime;

    @ApiModelProperty(value = "Check Out Time", required = true, example = "2021-02-08T23:00:00")
    private String checkOutTime;

    @ApiModelProperty(value = "parcel Details Json")
    private List<ParcelDetails> parcelDetailsJson;

}

