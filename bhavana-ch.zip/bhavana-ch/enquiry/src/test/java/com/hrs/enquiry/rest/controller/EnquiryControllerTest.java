package com.hrs.enquiry.rest.controller;

import com.hrs.enquiry.model.GuestDetails;
import com.hrs.enquiry.rest.json.GuestRequest;
import com.hrs.enquiry.rest.json.GuestResponse;
import com.hrs.enquiry.rest.json.RestResponse;
import com.hrs.enquiry.service.EnquiryService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class EnquiryControllerTest {

    @Mock
    EnquiryService enquiryService;

    @InjectMocks
    EnquiryController enquiryController;

    @BeforeEach
    void setUp(){ MockitoAnnotations.initMocks( this);
        when(enquiryService.insert(any())).thenReturn(new GuestDetails(1, "ALEX", 3, "102", LocalDateTime.now(),"CHECKED_IN",
                "DELUX", LocalDateTime.now(), null));

        RestResponse<GuestResponse> result = enquiryController.addNewGuest(new GuestRequest(1, "CHECKED_IN", "ALEX", "102",3, "DELUX", null));

        Assertions.assertAll("Guest Details",
                () -> Assertions.assertEquals(1, result.getData().getGuestId()),
                () -> Assertions.assertEquals("ALEX", result.getData().getGuestName()),
                () -> Assertions.assertEquals("102", result.getData().getRoomNo()),
                () -> Assertions.assertEquals("CHECKED_IN", result.getData().getStatus())

        );
    }

    @DisplayName("Guests Checked In")
    @Test
    void testfindAll(){
        when(enquiryService.findAll()).thenReturn(Arrays.asList(new GuestDetails(1, "ALEX", 3, "102", LocalDateTime.now(),"CHECKED_IN",
                "DELUX", LocalDateTime.now(), null)));

        RestResponse<List<GuestResponse>> result = enquiryController.findAll();
        Assertions.assertEquals(1, result.getData().size());
    }

    @DisplayName("Update Guest Record")
    @Test
    void testUpdate(){

        when( enquiryService.update(any(), any())).thenReturn(new GuestDetails(1, "ALEX", 3, "102", LocalDateTime.now(),"CHECKED_IN",
                "DELUX", LocalDateTime.now(), null));
        RestResponse<GuestResponse> result = enquiryController.update(any(), any());
        Assertions.assertAll("Guest Details",
                () -> Assertions.assertEquals(1, result.getData().getGuestId()),
                () -> Assertions.assertEquals("ALEX", result.getData().getGuestName()),
                () -> Assertions.assertEquals("102", result.getData().getRoomNo()),
                () -> Assertions.assertEquals("CHECKED_IN", result.getData().getStatus())

        );
    }
}
