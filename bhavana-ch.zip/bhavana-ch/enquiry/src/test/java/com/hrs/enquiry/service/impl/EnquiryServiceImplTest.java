package com.hrs.enquiry.service.impl;

import com.hrs.enquiry.model.GuestDetails;
import com.hrs.enquiry.repository.GuestDetailsRepository;
import com.hrs.enquiry.rest.json.ParcelDetails;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

public class EnquiryServiceImplTest {

    @Mock
    GuestDetailsRepository guestDetailsRepository;

    @InjectMocks
    EnquiryServiceImpl enquiryServiceimpl;

    @BeforeEach
    void setUp(){
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testInsert(){

        GuestDetails guestDetails = new GuestDetails(1, "ALEX", 3, "102", LocalDateTime.now(),"CHECKED_IN",
                "DELUX", LocalDateTime.now(), null);

        when(guestDetailsRepository.save(guestDetails)).thenReturn(guestDetails);

        GuestDetails result = enquiryServiceimpl.insert(guestDetails);

        Assertions.assertAll("Guest Details",
                () -> Assertions.assertEquals(1, result.getGuestId()),
                () -> Assertions.assertEquals("ALEX", result.getGuestName()),
                () -> Assertions.assertEquals("102", result.getRoomNo()),
                () -> Assertions.assertEquals("CHECKED_IN", result.getStatus())
        );
    }

    @Test
    void testUpdate(){
        GuestDetails guestDetails = new GuestDetails(1, "ALEX", 3, "102", LocalDateTime.now(),"CHECKED_IN",
                "DELUX", LocalDateTime.now(), null);

        when(guestDetailsRepository.findByRoomNoAndStatus(anyString(), anyString())).thenReturn(Optional.of(new GuestDetails(1, "ALEX", 3, "102", LocalDateTime.now(),"CHECKED_IN",
                "DELUX", LocalDateTime.now(), null)));

        GuestDetails result = enquiryServiceimpl.update(Arrays.asList(new ParcelDetails(1, "additional info")), "102");

        when(guestDetailsRepository.save(guestDetails)).thenReturn(guestDetails);
    }
}
